

function setup() {

	createCanvas(480, 120);
}

function draw() {

	background(204);

	owl(110, 110); // calling the 'owl' function, passing x and y position coordinates

	owl(180, 110); // calling the 'owl' function a second time with new x and y position coordinates
}
function setup() {
  createCanvas(400, 400);
}

function draw() {
  
  
  background(220);
  
  
  for (var i = 10; i < width + 20; i += 20)
    {
      littleMan(i, 110);
    }
  
}
function littleMan(x, y)
{
  
  push();
  var rotations = 0;
  translate(x, y);
  scale(0.5);
  angleMode(DEGREES)
  rotate(x)
  rotations++;
  angleMode(RADIANS)
  arc(20, 30, 40, 40, 0.52, 5.76);
  
  pop();
  print(printReturn(rotations));
}

function printReturn(x)
{
  return x;
}