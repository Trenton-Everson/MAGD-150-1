function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(200);
  
  
  colorMode(RGB, 255, 255, 255, 1);
  
  fill(255, 255, 255);
  triangle(82, 155, 100, 120, 118, 155);
  ellipse(100, 100, 50, 75);
  noFill();
  bezier(105, 155, 150, 200, 190, 190, 185, 200);
  
  fill(255, 155, 255);
  triangle(182, 155, 200, 120, 218, 155);
  ellipse(200, 100, 50, 75);
  noFill();
  bezier(202, 155, 150, 200, 190, 190, 185, 200);
  
  fill(255, 155, 95);
  triangle(282, 155, 300, 120, 318, 155);
  ellipse(300, 100, 50, 75);
  noFill();
  bezier(302, 155, 150, 200, 190, 190, 185, 200);
  
  fill(255, 255, 255);
  quad(232, 250, 130, 250, 150, 200, 212, 200);

  fill(100, 100, 100);
  text("1 Ton", 167, 230);
  
}
