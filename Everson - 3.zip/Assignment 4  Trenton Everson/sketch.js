function setup() {
  createCanvas(400, 400);
}
var f = 0;
function draw() {
  background(220);

  if (keyIsPressed)
    {
          for (var i = 20; i <= 40; i++)
            { 
             textSize(i)
             
            }
          text("You pressed " + key, 30 + i, 30);
    }
  
}
function mouseClicked()
{
  f++;
  
  if (f % 2 == 0)
  {
    textStyle(BOLD);
  }
  else if (f % 2 == 1)
    {
      textStyle(NORMAL)
    }
}